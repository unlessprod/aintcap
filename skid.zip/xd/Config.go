package main


var Banner = 	"\033[31mSmart HTTP Flood by bnt\n" +
				"Status: Syntax Error!\n      * Follow the Syntax below\n" +
				"      %s.us.path% version=<version> host=<host> domain=<host header> limit=<rs-ip> time=<time> good=<proxy> threads=<threads> mode=GET/POST cookie=<ddos=true> data=<post=true>\033[39m\n"
